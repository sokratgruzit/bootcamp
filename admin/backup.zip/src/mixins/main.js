export default {
	methods:{
		objectEquate(obj1, obj2){
			return true;	
		},
	}
}