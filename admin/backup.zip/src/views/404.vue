<template>
	<div class="error">
		Error Page
	</div>
</template>

<style lang="scss" scoped>
	.error{
		height: 100vh;
	}
</style>