 module.exports = {
	secret: "core secret key"
}